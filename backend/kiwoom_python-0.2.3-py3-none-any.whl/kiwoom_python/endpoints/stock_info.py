import json

from kiwoom_python.api import KiwoomAPI

MARKET_TYPES = {
    "코스피": "0", "코스닥": "10",
    "ELW": "3", "ETF": "8", "K-OTC": "30",
    "코넥스": "50", "신주인수권": "5", "뮤추얼펀드": "4",
    "리츠": "6", "하이일드": "9"
}


class StockInfo:
    def __init__(self, api: KiwoomAPI):
        self.api = api
        self.host = api.host
        self.endpoint = "/api/dostk/stkinfo"

    def get_stock_basic_info(self, stock_code: str) -> dict:
        '''
        주식기본정보요청 [ka10001]
        :param stock_code: 주식 코드
        :param cont_yn: 연속조회여부
        :param next_key: 연속조회키
        :return: 응답을 딕셔너리로 변환하여 반환
        '''
        headers = {'api-id': 'ka10001'}
        body = {"stk_cd": stock_code}
        ret = self.api.post(self.endpoint, headers, body)
        return ret

    def get_stock_list(self, market_type: str = "0") -> list[dict]:
        """
        종목정보 리스트 [ka10099]
        :param market_type: 시장구분 0:코스피,10:코스닥,3:ELW,8:ETF,30:K-OTC,50:코넥스,5:신주인수권,4:뮤추얼펀드,6:리츠,9:하이일드
        :return: 종목의 리스트
        """
        if not market_type.isdigit():
            assert market_type in MARKET_TYPES, f"잘못된 market_type입니다. {market_type}"
        headers = {'api-id': 'ka10099'}
        body = {"mrkt_tp": market_type}
        ret = self.api.continuous_query(self.endpoint, headers, body, "list")
        return ret["content"]["list"]


# if __name__ == "__main__":
#     # mock
#     APP_KEY = "."
#     SECRET_KEY = "."
#     info = StockInfo(KiwoomAPI(APP_KEY, SECRET_KEY))
#     ls = info.get_stock_list()
#     for d in ls:
#         print(f"{d['name']}[{d['code']}], lastPrice: {d['lastPrice']}")
#     print(f"Got {len(ls)} stock info")