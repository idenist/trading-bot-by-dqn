import asyncio
import json
from collections import defaultdict
import websockets
from typing import Set, Dict, Any


class KiwoomDataManager:
    _instance = None

    # 싱글톤 패턴 적용
    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(KiwoomDataManager, cls).__new__(cls)
        return cls._instance

    def __init__(self, api):
        if hasattr(self, 'initialized'):
            return

        self.endpoint = f"wss://{'mock' if api.mock else ''}api.kiwoom.com:10000/api/dostk/websocket"
        self.websocket = None
        self.connected = False
        self.persist = True
        self.api = api

        # ⭐️ 외부 서버로부터 받은 데이터를 임시 저장하는 큐
        self.data_queue = asyncio.Queue()

        # ⭐️ 클라이언트 구독 정보 관리
        # 예: {'005930': {client1_id, client2_id}, '000660': {client2_id}}
        self.item_subscribers: Dict[str, Set[Any]] = defaultdict(set)

        # ⭐️ 현재 외부 서버에 등록된 아이템
        self.current_subscriptions: Set[str] = set()

        self.initialized = True

    async def connect(self):
        if self.connected:
            return

        # 연결 시도
        try:
            self.websocket = await websockets.connect(self.endpoint)
            self.connected = True
            print("[websocket] : 연결 시도중")

            param = {
                'trnm': 'LOGIN',
                'token': self.api.token.token
            }

            print("[websocket] : 로그인 중")
            await self.send_message(param)
        except Exception as e:
            print(f'[websocket] : 연결 오류 - {e}')
            self.connected = False

        # 로그인 상태 검사
        try:
            response = json.loads(await self.websocket.recv())
            # 메시지 유형이 LOGIN일 경우 로그인 시도 결과 체크
            if response.get('trnm') == 'LOGIN':
                if response.get('return_code') != 0:
                    print('[websocket] : 로그인 실패 - ', response.get('return_msg'))
                    await self.disconnect()
                else:
                    print('[websocket] : 로그인 성공')
        except Exception as e:
            print(f'[websocket] : 로그인 오류 - {e}')

    # 서버에 메시지를 보냄. 연결이 없다면 자동으로 연결.
    async def send_message(self, message: dict):
        """
        서버에 메시지를 보냄.
        :param message: json 형식의 딕셔너리
        :return:
        """
        assert self.connected, "[websocket::send_message] 오류 - 웹소켓이 연결되지 않음"
        time.sleep(self.api.request_throttler.get_wait_time())
        message = json.dumps(message)
        await self.websocket.send(message)
        print(f'[websocket] : Sent message. - ' + message)

    async def disconnect(self):
        self.persist = False
        if self.connected and self.websocket:
            await self.websocket.close()
            self.connected = False
            print('[websocket] : 연결 종료됨')
        pass

    # ⭐️ 핵심 수정 부분: 메시지 수신 로직 변경
    async def receive_messages(self):
        self.persist = True
        while self.persist:
            try:
                response = json.loads(await self.websocket.recv())

                if response.get('trnm') == 'PING':
                    await self.send_message(response)
                    continue

                if response.get('trnm') != 'PING':
                    print(f'[websocket] : 실시간 시세 서버 응답 수신 - {response}')
                    # ⭐️ 받은 데이터를 큐에 넣어서 처리
                    await self.data_queue.put(response)

            except websockets.ConnectionClosed:
                print('[websocket] : 서버에 의해 연결이 종료되었습니다. 재연결 시도...')
                self.connected = False
                # ⭐️ 연결이 끊기면 재연결 로직 추가
                await self.reconnect_and_resubscribe()
            except asyncio.CancelledError:
                print('[websocket] : 작업이 취소되었습니다. 연결을 종료합니다.')
                await self.disconnect()
                raise
            except Exception as e:
                print(f'[websocket] : 메시지 수신 중 오류 발생 - {e}')

    # ⭐️ 구독 관리 메서드 추가
    async def add_subscriber(self, client_id, item: str):
        self.item_subscribers[item].add(client_id)
        # 새로운 아이템이면 외부 서버에 구독 요청
        if item not in self.current_subscriptions:
            self.current_subscriptions.add(item)
            await self._update_remote_subscription()

    async def remove_subscriber(self, client_id, item: str):
        if client_id in self.item_subscribers[item]:
            self.item_subscribers[item].remove(client_id)
        # 더 이상 이 아이템을 구독하는 클라이언트가 없으면 외부 서버에 구독 해지
        if not self.item_subscribers[item]:
            self.current_subscriptions.discard(item)
            await self._update_remote_subscription()

    async def _update_remote_subscription(self):
        # Kiwoom API에 맞게 REG 메시지를 동적으로 생성하여 보냄
        # ⭐️ 주의: Kiwoom API는 item 배열이 길고 복잡하므로, 실제 사용 시에는 포맷에 맞게 구성해야 함
        message = {
            'trnm': 'REG',
            'grp_no': '1',
            'refresh': '1',
            "data": [{
                "item": list(self.current_subscriptions),
                "type": ["0H"] * len(self.current_subscriptions)  # 예시: 실시간 체결가만 요청
            }]
        }
        await self.send_message(message)

    async def reconnect_and_resubscribe(self):
        await self.connect()
        if self.connected:
            await self._update_remote_subscription()

    async def run(self):
        # 서버 시작 시 한 번만 호출
        await self.connect()
        if self.connected:
            asyncio.create_task(self.receive_messages())