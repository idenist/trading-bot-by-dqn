import unittest
from kiwoom_python.api import KiwoomAPI
from kiwoom_python.endpoints.account import Account
from tests.test_config import APP_KEY, SECRET_KEY


class TestAccount(unittest.TestCase):
    def test_account_methods_no_error(self):
        """
        Account 클래스의 메서드들이 오류 없이 실행되는지 테스트
        """
        # Given: KiwoomAPI가 mock 모드로 초기화되고 Account 클래스가 인스턴스화되었을 때
        try:
            api = KiwoomAPI(APP_KEY, SECRET_KEY, mock=True)
            account = Account(api)
        except Exception as e:
            self.fail(f"Initialization failed: {e}")

        # When: 각 메서드가 호출될 때
        try:
            # 계좌 수익률 요청
            profit_rate = account.get_account_profit_rate()
            self.assertIsNotNone(profit_rate, "get_account_profit_rate should return a value")

            # 계좌 평가 현황 조회 요청
            evaluation = account.get_account_evaluation(domestic_stex_type="KRX")
            self.assertIsNotNone(evaluation, "get_account_evaluation should return a value")

        except Exception as e:
            # Then: 예외가 발생하지 않아야 함
            self.fail(f"Method call failed with exception: {e}")


if __name__ == '__main__':
    unittest.main()