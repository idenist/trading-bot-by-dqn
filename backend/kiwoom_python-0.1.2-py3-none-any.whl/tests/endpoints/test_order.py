import unittest
from kiwoom_python.api import KiwoomAPI
from kiwoom_python.endpoints.order import Order, TradeType

from tests.test_config import APP_KEY, SECRET_KEY


class TestOrder(unittest.TestCase):
    def test_order_methods_no_error(self):
        """
        Order 클래스의 메서드들이 오류 없이 실행되는지 테스트합니다.
        """
        # Given: KiwoomAPI가 mock 모드로 초기화되고 Order 클래스가 인스턴스화되었을 때
        try:
            api = KiwoomAPI(APP_KEY, SECRET_KEY, mock=True)
            order = Order(api)
        except Exception as e:
            self.fail(f"Initialization failed: {e}")

        # When: 각 메서드가 호출될 때
        try:
            # 매수 주문
            buy_order_no = order.buy("KRX", "005930", 1, TradeType.시장가.value)
            self.assertIsNotNone(buy_order_no, "buy should return an order number")

            # 매도 주문
            sell_order_no = order.sell("KRX", "005930", 1, TradeType.시장가.value)
            self.assertIsNotNone(sell_order_no, "sell should return an order number")

            # 정정 주문 (mock이므로 원주문번호는 임의의 값을 사용)
            modify_order_no = order.modify("KRX", "12345", "005930", 1, 10000)
            self.assertIsNotNone(modify_order_no, "modify should return an order number")

            # 취소 주문 (mock이므로 원주문번호는 임의의 값을 사용)
            cancel_order_no = order.cancel("KRX", "12345", "005930")
            self.assertIsNotNone(cancel_order_no, "cancel should return an order number")

        except Exception as e:
            # Then: 예외가 발생하지 않아야 합니다.
            self.fail(f"Method call failed with exception: {e}")


if __name__ == '__main__':
    unittest.main()