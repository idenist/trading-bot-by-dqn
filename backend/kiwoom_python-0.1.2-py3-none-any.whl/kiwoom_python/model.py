from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime
from zoneinfo import ZoneInfo
import json
import re
from typing import Optional, Any, List, Dict

# TODO
# - [ ] Chart dataclass for charting. Combine poles to dataframe.
# - [ ] Deserialize chart for json tranport
# - [ ] Restructure chart data for RL model

KST = ZoneInfo("Asia/Seoul")


@dataclass
class Token:
    """
    인증 토큰 객체
    """
    expire_date: datetime | None = None
    token_type: str | None = None
    token: str | None = None

    @classmethod
    def from_response(cls, response):
        """
        API 토큰 요청의 응답을 사용하여 초기화.
        :param response: 성공한 토큰 생성 요청의 응답 (requests.Response)
        :return: Token 인스턴스
        """
        response_dict = json.loads(response)
        if response_dict["return_code"] == 3:
            raise Exception(response_dict["return_msg"])
        return cls(
            expire_date=datetime.strptime(response_dict["expires_dt"], "%Y%m%d%H%M%S").replace(tzinfo=KST),
            token_type=response_dict["token_type"],
            token=response_dict["token"]
        )

    def is_valid(self):
        """
        토큰의 유효성 검사.
        :return: bool 아직 생성이 되지 않은 경우, 토큰이 만료된 경우 False를, 그외 True를 리턴.
        """
        return self.token is not None and self.expire_date > datetime.now(tz=KST)


def tfm(string: str) -> str:
    return f"{string[:4]}-{string[4:6]}-{string[6:8]} {string[8:10]}:{string[10:12]}:{string[12:14]}" + "" if len(
        string) == 14 else f".{string[14:]}"

def to_unixtime(string: str) -> int:
    import datetime
    dt_object = datetime.datetime.strptime(string, "%Y-%m-%d %H:%M:%S")
    return int(dt_object.timestamp())


@dataclass
class SimplePole:
    open: float
    close: float
    high: float
    low: float
    volume: int
    trade_time: str = None
    timestamp: int = None

    @classmethod
    def from_raw_data(cls, data):
        """
        API 응답을 사용하여 초기화한 인스턴스 리턴
        :param data:
        :return: SimplePole 인스턴스
        """
        d, t = data.get("dt", None), data.get("cntr_tm", None)
        if d is None:
            trade_time = tfm(t)
        else:
            trade_time = tfm(d + "000000")

        o = float(re.findall(r'-?(-*.*)', data["open_pric"])[0])
        h = float(re.findall(r'-?(-*.*)', data["high_pric"])[0])
        l = float(re.findall(r'-?(-*.*)', data["low_pric"])[0])
        c = float(re.findall(r'-?(-*.*)', data["cur_prc"])[0])

        h, l = max((o, h, l, c)), min((o, h, l, c))

        return cls(
            open=o,
            high=h,
            low=l,
            close=c,
            volume=int(data["trde_qty"]),
            trade_time=trade_time,
            timestamp=to_unixtime(trade_time) * 1000
        )

    def __str__(self):
        return f"[{self.trade_time}] OPEN: {self.open} | CLOSE: {self.close} | HIGH: {self.high} | LOW: {self.low} | VOLUME: {self.volume}"

    def to_minimal_dict(self):
        return {"timestamp": self.timestamp, "open": self.open, "high": self.high, "low": self.low, "close": self.close}


@dataclass
class Chart:
    pass


@dataclass
class AccountEntry:
    """
    계좌의 종목 하나를 모델링
    """
    @classmethod
    def from_raw_data(cls, data):
        """
        API 응답을 사용하여 초기화한 인스턴스 리턴
        :param data:
        :return: AccountEntry 인스턴스
        """
        return cls(
            dt=data["dt"],
            stock_code=data["stk_cd"],
            stock_name=data["stk_nm"],
            current_price=float(re.findall(r'-?(-*.*)', data["cur_prc"])[0]),
            purchase_price=float(data["pur_pric"]),
            purchase_amount=float(data["pur_amt"]),
            remainder_quantity=float(data["rmnd_qty"]),
            today_sell_profit_loss=float(data["tdy_sel_pl"]),
            today_trade_commission=float(data["tdy_trde_cmsn"]),
            today_trade_tax=float(data["tdy_trde_tax"])
        )

    dt: str
    stock_code: str
    stock_name: str
    current_price: float
    purchase_price: float
    purchase_amount: float
    remainder_quantity: float
    today_sell_profit_loss: float
    today_trade_commission: float
    today_trade_tax: float

    def to_dict(self):
        return {k: str(v) for k, v in asdict(self).items()}


@dataclass
class AccountEval:
    """
    계좌 평가 내역을 모델링
    """
    @classmethod
    def from_raw_data(cls, data):
        """
        API 응답 데이터로 초기화
        :param data:
        :return: AccountEval 인스턴스
        """
        return cls(
            name=data["acnt_nm"],
            deposit=float(data["entr"]),
            total_estimated=float(data["tot_est_amt"]),
            total_purchased=float(data["tot_pur_amt"]),
            presumed_asset=float(data["prsm_dpst_aset_amt"]),
            daily_profit=float(data["tdy_lspft"]),
            monthly_profit=float(data["lspft2"]),
            cumulative_profit=float(data["lspft"]),
            daily_profit_rate=float(data["tdy_lspft_rt"]),
            monthly_profit_rate=float(data["lspft_ratio"]),
            cumulative_profit_rate=float(data["lspft_rt"])
        )

    name: str
    deposit: float  # 예수금
    total_estimated: float  # 현재 보유 주식 가치의 단순 합산(유가잔고평가액)
    total_purchased: float  # 총 매수 금액
    presumed_asset: float  # 추정 자산
    # 모두 실현 손익 기준
    daily_profit: float  # 당일 손익
    monthly_profit: float  # 당월 손익
    cumulative_profit: float  # 누적 손익
    daily_profit_rate: float  # 당일 손익률
    monthly_profit_rate: float  # 당월 손익률
    cumulative_profit_rate: float  # 누적 손익률

    def to_dict(self):
        return {k: str(v) for k, v in asdict(self).items()}
