import time
from collections import deque

from requests import request

from kiwoom_python.model import *


class RequestThrottler:
    _instance = None

    def __new__(cls, max_requests_per_second: float = 5):
        """
        API 호출 횟수 제한용 싱글톤 클래스
        :param max_requests_per_second: 1초 동안 최대로 보낼 수 있는 요청 회수
        """
        if cls._instance is None:
            if max_requests_per_second <= 0:
                raise ValueError("max_requests_per_second must be greater than 0.")
            cls._instance = super(RequestThrottler, cls).__new__(cls)
            cls._instance.max_requests_per_second = max_requests_per_second
            cls._instance.last_request_timestamp = time.time()
            cls._instance.q = deque()
        return cls._instance

    def get_wait_time(self) -> float:
        """
        초당 요청 횟수를 유지하기 위해 대기를 얼마나 해야하는지
        슬라이딩 윈도우 알고리즘 기반
        :return: 대기해야할 시간
        """
        # 너무 큰 경우 사실상 제한이 없는 것으로 취급. (키움 api는 1초에 5번)
        if self.max_requests_per_second > 1000000:
            return 0.0

        now = time.time()

        # T-1 이전 기록 제거
        while len(self.q) and now - self.q[0] > 1.0:
            self.q.popleft()

        # 이전 요청들 개수가 최대값 미만인 경우 즉시 허용
        if len(self.q) < self.max_requests_per_second:
            self.q.append(now)
            return 0.0

        # 이전 요청이 5개인 경우. 가장 오래된 시각+1초 까지 대기하도록 대기시간 리턴
        return 1.0 - (now - self.q[0])


class KiwoomAPI:
    def __init__(self, app_key, secret_key, mock=True):
        """
        API 래퍼 인스턴스를 생성.
        :param app_key: App Key
        :param secret_key: App Secret
        :param mock: 모의투자 여부. 기본값은 True.
        """
        self.host = "https://mockapi.kiwoom.com" if mock else "https://api.kiwoom.com"
        self.mock = mock
        self._app_key = app_key
        self._app_secret = secret_key
        self.token = self._issue_token()
        self.request_throttler = RequestThrottler(5)

    def _issue_token(self):
        endpoint = "/oauth2/token"
        headers = {
            "Content-Type": "application/json;charset=UTF-8"
        }
        body = {
            "grant_type": "client_credentials",
            "appkey": self._app_key,
            "secretkey": self._app_secret
        }
        response = request("POST", self.host + endpoint, headers=headers, json=body)
        if response.status_code != 200:
            raise Exception(f"HTTP error. {json.loads(response.content.decode('utf-8'))['return_msg']}")
        return Token.from_response(response.content.decode("utf-8"))

    def _refresh_token(self):
        if not self.token.is_valid():
            self._token = self._issue_token()

    def invalidate_token(self):
        '''
        토큰을 폐기.
        :return: 없음
        '''
        endpoint = "/oauth2/token"
        headers = {
            "Content-Type": "application/json;charset=UTF-8"
        }
        body = {
            "grant_type": "client_credentials",
            "appkey": self._app_key,
            "secretkey": self._app_secret
        }
        self.post(endpoint, headers, body)

    def post(self, endpoint: str, headers: dict, body: dict, cont_yn="N", next_key=""):
        """
        POST 요청
        :param endpoint: URL
        :param headers: 헤더 설정. authorization, Content-Type, cont-yn, next-key는 메소드에서 자동 처리
        :param body: 요청 내용
        :param cont_yn: 연속조회여부
        :param next_key: 연속조회키
        :return: requests.Response 객체
        """
        # 초당 요청 회수 제한 (5 req/s)
        wait_time = self.request_throttler.get_wait_time()
        if wait_time > 0:
            time.sleep(wait_time)

        # 토큰 갱신
        self._refresh_token()

        # 헤더 구성
        headers["authorization"] = self.token.token_type + ' ' + self.token.token
        headers["Content-Type"] = 'application/json;charset=UTF-8'
        headers["cont-yn"] = cont_yn
        headers["next-key"] = next_key

        # POST 요청
        ret = request("POST", self.host + endpoint, headers=headers, json=body)

        # header, content, status_code, reason만 딕셔너리에 저장 후 리턴
        deserialized = {
            "headers": ret.headers,
            "content": json.loads(ret.content.decode("utf-8")),
            "status_code": ret.status_code,
            "reason": ret.reason
        }
        return deserialized

    def continuous_query(
            self,
            endpoint: str,
            headers: dict,
            body: dict,
            continuous_data_name: str,
            amount: int = 100,
            max_request: int = 300,
    ) -> dict:
        """
        연속 데이터를 지정한 범위(0 이하인 경우 끝날 때 까지) 받아옴.
        :param endpoint: api 엔드포인트 주소
        :param headers: 요청 헤더
        :param body: 요청 내용
        :param continuous_data_name: 연속 데이터를 포함하는 리스트의 키 값
        :param amount: 최소 요쳥량. 받아온 데이터 개수가 이 값을 넘으면 요청을 중단하고 리턴. 음수인 경우 제한을 두지 않음.
        :param max_request: 최대 요청 횟수.
        :return: 받아온 데이터를 병합한 딕셔너리
        """
        assert max_request > 0, "최대 요청 횟수 max_request는 0보다 커야 합니다."

        # 연속 요청 값 및 관련 변수 초기화
        cont_yn = "N"
        next_key = ""
        cnt = 0

        # 연속 데이터를 누적 저장할 변수
        continuous_data = []
        response = None
        while True:
            # 지정된 개수 이상의 데이터를 받은 경우, 최대 요청 회수에 도달한 경우 종료
            if 0 < amount <= len(continuous_data) or cnt > max_request:
                break

            # api 호출 - 디코딩 - 파싱
            response = self.post(endpoint, headers, body, cont_yn, next_key)
            if response["status_code"] >= 400:
                print(f"[api] 오류 코드 {response['status_code']} - {response['reason']}")
                print(f"\t{response['content']['return_code']} - {response['content']['return_msg']}")
                raise
            resp_json = response["content"]

            # 요청 오류
            if resp_json["return_code"] > 0:
                break

            # 데이터 처리
            continuous_data += resp_json[continuous_data_name][:]
            cont_yn = response["headers"]["cont-yn"]
            next_key = response["headers"]["next-key"]

            # 남은 연속 데이터 없음
            if cont_yn == "N":
                break
        # ---

        # 마지막 response에 continuous_data를 덮어씌워 리턴
        response["content"][continuous_data_name] = continuous_data
        return response

