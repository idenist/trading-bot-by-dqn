import json
import time

from kiwoom_python.api import KiwoomAPI
from kiwoom_python.model import AccountEntry, AccountEval


class Account:
    def __init__(self, api: KiwoomAPI):
        self.api = api
        self.endpoint = "/api/dostk/acnt"

    def get_account_profit_rate(self) -> list[AccountEntry]:
        """
        계좌 수익률 요청 [ka10085]
        :param stex_type: 거래소 유형 (모의 투자는 KRX만 지원)
        :return: 종목별 수익률
        """
        headers = {"api-id": "ka10085"}
        body = {"stex_tp": "0"}
        resp = self.api.continuous_query(self.endpoint, headers, body, "acnt_prft_rt")
        assert resp["content"]["return_code"] != 1, resp["content"]["return_msg"]
        ret = []
        for stk in resp["content"]["acnt_prft_rt"]:
            ret.append(AccountEntry.from_raw_data(stk))
        return ret

    def get_account_evaluation(self, domestic_stex_type, query_type="0"):
        """
        계좌 평가 현황 조회 요청 [kt00004]
        :param domestic_stex_type: 국내 거래소 구분 ("KRX" 또는 "NXT")
        :param query_type: 상장 폐지 조회 구분
        :return: 계좌 평가 현황
        """
        headers = {"api-id": "kt00004"}
        body = {
            "qry_tp": query_type,
            "dmst_stex_tp": domestic_stex_type
        }
        resp = self.api.post(self.endpoint, headers, body)
        assert resp["content"]["return_code"] != 1, resp["content"]["return_msg"]
        return AccountEval.from_raw_data(resp["content"])


if __name__ == "__main__":
    appkey = "CAJbpNofdEzBVpSC23SRRvkD8qxUxqJRjM5dagIp1PU"
    secretkey = "Sty0POpQV4Lk5OyfhKd09OzwCptnh9WQdgIfWlkpmTo"
    api = KiwoomAPI(appkey, secretkey, mock=True)
    acnt = Account(api)
    print("===== get_account_profit_rate test")
    pp = acnt.get_account_profit_rate()
    print(pp)
    ppp = pp[0].to_dict()
    for k in ppp:
        print(f"{k}; {type(ppp[k])}")
    print("===== get_account_profit_rate test")
    ev = acnt.get_account_evaluation("KRX")
    print(ev.to_dict())