import json

from kiwoom_python.api import KiwoomAPI


class StockInfo:
    def __init__(self, api: KiwoomAPI):
        self.api = api
        self.host = api.host
        self.endpoint = "/api/dostk/stkinfo"

    def get_stock_basic_info(self, stock_code: str) -> dict:
        '''
        주식기본정보요청 [ka10001]
        :param stock_code: 주식 코드
        :param cont_yn: 연속조회여부
        :param next_key: 연속조회키
        :return: 응답을 딕셔너리로 변환하여 반환
        '''
        headers = {'api-id': 'ka10001'}
        body = {"stk_cd": stock_code}
        ret = self.api.post(self.endpoint, headers, body)
        return ret
