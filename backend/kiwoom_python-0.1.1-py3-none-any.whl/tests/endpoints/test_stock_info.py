import unittest
from kiwoom_python.api import KiwoomAPI
from kiwoom_python.endpoints.stock_info import StockInfo

from tests.test_config import APP_KEY, SECRET_KEY


class TestStockInfo(unittest.TestCase):
    def test_stock_info_methods_no_error(self):
        """
        StockInfo 클래스의 메서드들이 오류 없이 실행되는지 테스트
        """
        # Given: KiwoomAPI가 mock 모드로 초기화되고 StockInfo 클래스가 인스턴스화되었을 때
        try:
            api = KiwoomAPI(APP_KEY, SECRET_KEY, mock=True)
            info = StockInfo(api)
        except Exception as e:
            self.fail(f"Initialization failed: {e}")

        # When: 각 메서드가 호출될 때
        try:
            # 주식기본정보요청
            basic_info = info.get_stock_basic_info("005930")
            self.assertIsNotNone(basic_info, "get_stock_basic_info should return a value")

        except Exception as e:
            # Then: 예외가 발생하지 않아야 함
            self.fail(f"Method call failed with exception: {e}")


if __name__ == '__main__':
    unittest.main()