import json
import time
from copy import deepcopy

from kiwoom_python.api import KiwoomAPI
from kiwoom_python.model import SimplePole


class Chart:
    def __init__(self, api: KiwoomAPI):
        self.api = api
        self.host = api.host
        self.endpoint = "/api/dostk/chart"

    def get_stock_daily_chart(
            self,
            stock_code: str,
            base_date: str,
            updated_stock_price_type: bool,
            amount: int = 0,
            max_request: int = 300,
    ) -> list[SimplePole]:
        """
        주식일봉차트조회요청 [ka10081]
        :param stock_code: 주식 코드
        :param base_date: 기준일자, YYYYMMDD 형식 (ex. 20241221)
        :param updated_stock_price_type: 수정주가 요청 여부
        :param amount: 최소 요쳥량. 받아온 데이터 개수가 이 값을 넘으면 요청을 중단하고 리턴합니다. 음수인 경우 제한을 두지 않습니다.
        :param max_request: 최대 요청 횟수.
        :return: 응답을 딕셔너리로 변환하여 반환
        """
        headers = {'api-id': 'ka10081'}
        body = {
            "stk_cd": stock_code,
            "base_dt": base_date,
            "upd_stkpc_tp": "1" if updated_stock_price_type else "0"
        }
        ret = self.api.continuous_query(self.endpoint, headers, body, "stk_dt_pole_chart_qry", amount, max_request)
        pole_chart = [SimplePole(**SimplePole.adapter(x)) for x in ret["content"]["stk_dt_pole_chart_qry"]]
        print(len(pole_chart))
        return pole_chart

    def get_stock_minute_chart(
            self,
            stock_code: str,
            tick_scope: int,
            updated_stock_price_type: bool,
            amount: int = 0,
            max_request: int = 300
    ) -> list[SimplePole]:
        '''
        주식분봉차트조회요청 [ka10080]
        :param stock_code: 주식 코드
        :param tick_scope: 틱 단위, [1, 3, 5, 10, 15, 30, 45, 60]
        :param updated_stock_price_type: 수정주가 요청 여부
        :param amount: 최소 요쳥량. 받아온 데이터 개수가 이 값을 넘으면 요청을 중단하고 리턴합니다. 음수인 경우 제한을 두지 않습니다.
        :param max_request: 최대 요청 횟수.
        :return: 응답을 딕셔너리로 변환하여 반환
        '''
        assert tick_scope in [1, 3, 5, 10, 15, 30, 45, 60], "tick_scope 값은 1, 3, 5, 10, 15, 30, 45, 60 중 하나여야 함"
        headers = {'api-id': 'ka10080'}
        body = {
            "stk_cd": stock_code,
            "tic_scope": str(tick_scope),
            "upd_stkpc_tp": "1" if updated_stock_price_type else "0"
        }
        ret = self.api.continuous_query(self.endpoint, headers, body, "stk_min_pole_chart_qry", amount, max_request)
        pole_chart = [SimplePole(**SimplePole.adapter(x)) for x in ret["content"]["stk_min_pole_chart_qry"]]
        return pole_chart[:100]

    def get_stock_tick_chart(
            self,
            stock_code: str,
            tick_scope: int,
            updated_stock_price_type: bool,
            amount: int = 0,
            max_request: int = 300
    ) -> list[SimplePole]:
        """
        주식틱차트조회요청 [ka10079]
        :param stock_code: 주식 코드
        :param tick_scope: 틱 단위, [1, 3, 5, 10, 15, 30]
        :param updated_stock_price_type: 수정주가 요청 여부
        :param amount: 최소 요쳥량. 받아온 데이터 개수가 이 값을 넘으면 요청을 중단하고 리턴합니다. 음수인 경우 제한을 두지 않습니다.
        :param max_request: 최대 요청 횟수.
        :return: 응답을 딕셔너리로 변환하여 반환
        """
        assert tick_scope in [1, 3, 5, 10, 15, 30, 45, 60], "tick_scope 값은 1, 3, 5, 10, 15, 30, 45, 60 중 하나여야 함"
        headers = {'api-id': 'ka10079'}
        body = {
            "stk_cd": stock_code,
            "tic_scope": str(tick_scope),
            "upd_stkpc_tp": "1" if updated_stock_price_type else "0"
        }

        ret = self.api.continuous_query(self.endpoint, headers, body, "stk_tic_chart_qry", amount, max_request)
        pole_chart = [SimplePole(**SimplePole.adapter(x)) for x in ret["content"]["stk_tic_chart_qry"]]
        return pole_chart[:100]


if __name__ == "__main__":
    appkey = "CAJbpNofdEzBVpSC23SRRvkD8qxUxqJRjM5dagIp1PU"
    secretkey = "Sty0POpQV4Lk5OyfhKd09OzwCptnh9WQdgIfWlkpmTo"
    api = KiwoomAPI(appkey, secretkey, mock=True)
    chart = Chart(api)
    min_pole_chart = chart.get_stock_minute_chart("005930", 60, True, 1000)
    print(min_pole_chart[-1])
