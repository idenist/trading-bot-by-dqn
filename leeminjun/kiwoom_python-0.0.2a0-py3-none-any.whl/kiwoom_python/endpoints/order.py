import json

from kiwoom_python.api import KiwoomAPI

import enum


class TradeType(enum.Enum):
    보통 = 0
    시장가 = 3
    조건부지정가 = 5
    장마감후시간외 = 81
    장시작전시간외 = 61
    시간외단일가 = 62
    최유리지정가 = 6
    최우선지정자 = 7
    보통IOC = 10
    시장가IOC = 13
    최유리IOC = 16
    보통FOK = 20
    시장가FOK = 13
    최유리FOK = 16
    스톱지정가 = 8
    중간가 = 29
    중간가IOC = 30
    중간가FOK = 31


class Order:
    def __init__(self, api: KiwoomAPI):
        self.api = api
        self.endpoint = "/api/dostk/ordr"

    def buy(
            self,
            stex_type: str,
            stock_code: str,
            order_quantity: int,
            trade_type: int,
            order_unit_value: int = 0,
            conditional_unit_value: int = 0
    ) -> str:
        """
        주식 매수주문 [kt10000]
        매매 타입을 api 가이드를 참조하여 정수 입력 또는 TradeType를 import하여 사용할 수 있음

        예를 들어 시장가를 선택하려면 3 또는 TradeType.시장가.value 를 입력하면 됨
        :param stex_type: 거래소 유형 (모의 투자는 KRX만 지원)
        :param stock_code: 주식 코드
        :param order_quantity: 주문 수량
        :param trade_type: 매매 구분
        :param order_unit_value: 주문 단가
        :param conditional_unit_value: 조건 단가
        :return: 주문 번호 리턴
        """
        assert stex_type in ["KRX", "NXT", "SOR"], "거래소 타입이 잘못되었습니다."
        assert trade_type in [e.value for e in TradeType], f"존재하지 않는 매매 구분입니다. {trade_type}"
        if self.api.mock:
            assert stex_type == "KRX", "모의투자는 KRX만 지원합니다."
        headers = {"api-id": "kt10000"}
        body = {
            "dmst_stex_tp": stex_type,
            "stk_cd": stock_code,
            "ord_qty": str(order_quantity),
            "trde_tp": str(trade_type),
            "ord_uv": str(order_unit_value) if order_unit_value else "",
            "cond_uv": str(conditional_unit_value) if conditional_unit_value else "",
        }
        resp = json.loads(self.api.post(self.endpoint, headers, body).content.decode("utf-8"))
        if resp["return_code"]:
            print("거래 실패 - " + resp["return_msg"])
        return resp["ord_no"]

    def sell(
            self,
            stex_type: str,
            stock_code: str,
            order_quantity: int,
            trade_type: int,
            order_unit_value: int = 0,
            conditional_unit_value: int = 0
    ) -> str:
        """
        주식 매도주문 [kt10001]
        매매 타입을 api 가이드를 참조하여 정수 입력 또는 TradeType를 import하여 사용할 수 있음

        예를 들어 시장가를 선택하려면 3 또는 TradeType.시장가.value 를 입력하면 됨
        :param stex_type: 거래소 유형 (모의 투자는 KRX만 지원)
        :param stock_code: 주식 코드
        :param order_quantity: 주문 수량
        :param trade_type: 매매 구분
        :param order_unit_value: 주문 단가
        :param conditional_unit_value: 조건 단가
        :return: 주문 번호 리턴
        """
        assert stex_type in ["KRX", "NXT", "SOR"], "거래소 타입이 잘못되었습니다."
        assert trade_type in [e.value for e in TradeType], "존재하지 않는 매매 구분입니다."
        if self.api.mock:
            assert stex_type == "KRX", "모의투자는 KRX만 지원합니다."
        headers = {"api-id": "kt10001"}
        body = {
            "dmst_stex_tp": stex_type,
            "stk_cd": stock_code,
            "ord_qty": str(order_quantity),
            "trde_tp": str(trade_type),
            "ord_uv": str(order_unit_value) if order_unit_value else "",
            "cond_uv": str(conditional_unit_value) if conditional_unit_value else "",
        }
        resp = json.loads(self.api.post(self.endpoint, headers, body).content.decode("utf-8"))
        if resp["return_code"]:
            print("거래 실패 - " + resp["return_msg"])
        return resp["ord_no"]

    def modify(
            self,
            stex_type: str,
            origin_order_number: str,
            stock_code: str,
            modify_quantity: int,
            modify_unit_value: int = 0,
            modify_conditional_unit_value: int = 0
    ) -> str:
        """
        주식 정정주문 [kt10002]
        매매 타입을 api 가이드를 참조하여 정수 입력 또는 TradeType를 import하여 사용할 수 있음

        예를 들어 시장가를 선택하려면 3 또는 TradeType.시장가.value 를 입력하면 됨
        :param stex_type: 거래소 유형 (모의 투자는 KRX만 지원)
        :param origin_order_number: 원주문번호
        :param stock_code: 주식 코드
        :param modify_quantity: 주문 수량
        :param modify_unit_value: 주문 단가
        :param modify_conditional_unit_value: 조건 단가
        :return: 주문 번호 리턴
        """
        assert stex_type in ["KRX", "NXT", "SOR"], "거래소 타입이 잘못되었습니다."
        if self.api.mock:
            assert stex_type == "KRX", "모의투자는 KRX만 지원합니다."
        headers = {"api-id": "kt10000"}
        body = {
            "dmst_stex_tp": stex_type,
            "stk_cd": stock_code,
            "mdfy_qty": str(modify_quantity),
            "mdfy_uv": str(modify_unit_value) if modify_unit_value else "",
            "mdfy_cond_uv": str(modify_conditional_unit_value) if modify_conditional_unit_value else "",
        }
        resp = json.loads(self.api.post(self.endpoint, headers, body).content.decode("utf-8"))
        if resp["return_code"]:
            print("거래 실패 - " + resp["return_msg"])
        return resp["ord_no"]

    def cancel(
            self,
            stex_type: str,
            origin_order_number: str,
            stock_code: str,
    ) -> str:
        """
        주식 취소주문 [kt10003]
        매매 타입을 api 가이드를 참조하여 정수 입력 또는 TradeType를 import하여 사용할 수 있음

        예를 들어 시장가를 선택하려면 3 또는 TradeType.시장가.value 를 입력하면 됨
        :param stex_type: 거래소 유형 (모의 투자는 KRX만 지원)
        :param origin_order_number: 원주문번호
        :param stock_code: 주식 코드
        :return: 주문 번호 리턴
        """
        assert stex_type in ["KRX", "NXT", "SOR"], "거래소 타입이 잘못되었습니다."
        if self.api.mock:
            assert stex_type == "KRX", "모의투자는 KRX만 지원합니다."
        headers = {"api-id": "kt10000"}
        body = {
            "dmst_stex_tp": stex_type,
            "stk_cd": stock_code,
        }
        resp = json.loads(self.api.post(self.endpoint, headers, body).content.decode("utf-8"))
        if resp["return_code"]:
            print("거래 실패 - " + resp["return_msg"])
        return resp["ord_no"]


if __name__ == "__main__":
    appkey = "vNgsplYf-YPhiscDx8v987UmxMZvqyhvSjcgryvizNY"
    secretkey = "0sm8QR2DSois4kelH9GQHMDWiYRObKLmwSdjAYBtU20"
    api = KiwoomAPI(appkey, secretkey, mock=True)
    order = Order(api)
    buy_order_number = order.buy("KRX", "005930", 1, TradeType.시장가.value)
    sell_order_number = order.sell("KRX", "005930", 1, TradeType.시장가.value)
    print(sell_order_number)
