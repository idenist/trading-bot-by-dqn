import asyncio
import websockets
import json
from model import Token
from api import KiwoomAPI

# socket 정보
# SOCKET_URL = 'wss://mockapi.kiwoom.com:10000/api/dostk/websocket'  # 모의투자 접속 URL
SOCKET_URL = 'wss://api.kiwoom.com:10000/api/dostk/websocket'  # 접속 URL
ACCESS_TOKEN = '사용자 AccessToken'  # 고객 Access Token


class WebSocketClient:
    def __init__(self, app_key, app_secret, mock=False):
        self.endpoint = f"wss://{'mock' if mock else ''}api.kiwoom.com:10000/api/dostk/websocket"
        self.websocket = None
        self.connected = False
        self.persist = True
        self.api = KiwoomAPI(app_key, app_secret, mock)

    async def connect(self):
        if self.connected:
            return

        # 연결 시도
        try:
            self.websocket = await websockets.connect(self.endpoint)
            self.connected = True
            print("[websocket] : 연결 시도중")

            param = {
                'trnm': 'LOGIN',
                'token': self.api.token.token
            }

            print("[websocket] : 로그인 중")
            await self.send_message(param)
        except Exception as e:
            print(f'[websocket] : 연결 오류 - {e}')
            self.connected = False

        # 로그인 상태 검사
        try:
            response = json.loads(await self.websocket.recv())
            # 메시지 유형이 LOGIN일 경우 로그인 시도 결과 체크
            if response.get('trnm') == 'LOGIN':
                if response.get('return_code') != 0:
                    print('[websocket] : 로그인 실패 - ', response.get('return_msg'))
                    await self.disconnect()
                else:
                    print('[websocket] : 로그인 성공')
        except Exception as e:
            print(f'[websocket] : 로그인 오류 - {e}')

    # 서버에 메시지를 보냄. 연결이 없다면 자동으로 연결.
    async def send_message(self, message: dict):
        '''
        서버에 메시지를 보냄.
        :param message: json 형식의 딕셔너리
        :return:
        '''
        assert self.connected, "[websocket::send_message] 오류 - 웹소켓이 연결되지 않음"
        message = json.dumps(message)
        await self.websocket.send(message)
        print(f'[websocket] : Sent message. - ' + message)

    # 서버에서 오는 메시지를 수신하여 출력합니다.
    async def receive_messages(self):
        self.persist = True
        while self.persist:
            try:
                response = json.loads(await self.websocket.recv())

                if response.get('trnm') == 'PING':
                    await self.send_message(response)

                if response.get('trnm') != 'PING':
                    print(f'[websocket] : 실시간 시세 서버 응답 수신 - {response}')

            except websockets.ConnectionClosed:
                print('[websocket] : 서버에 의해 연결이 종료되었습니다.')
                self.connected = False
                await self.websocket.close()
            except asyncio.CancelledError:
                print('[websocket] : 작업이 취소되었습니다. 연결을 종료합니다.')
                await self.disconnect()
                raise
            except Exception as e:
                print(f'[websocket] : 메시지 수신 중 오류 발생 - {e}')

    # WebSocket 실행
    async def run(self):
        await self.connect()
        await self.receive_messages()

    # WebSocket 연결 종료
    async def disconnect(self):
        self.persist = False
        if self.connected and self.websocket:
            await self.websocket.close()
            self.connected = False
            print('[websocket] : 연결 종료됨')


async def main():
    appkey = "M3qimQ1uEbfq1DWFfLpRrGC4ER5cnErzjfk2QtO_Enw"
    secretkey = "1aJGOc-qvd3zt_-LtMP3NlNfDLFl6ebTiizU7zfjLV4"
    websocket_client = WebSocketClient(appkey, secretkey, True)

    # WebSocket 클라이언트를 백그라운드에서 실행
    receive_task = asyncio.create_task(websocket_client.run())

    # 실시간 항목 등록
    await asyncio.sleep(1)
    await websocket_client.send_message({
        'trnm': 'REG',  # 서비스명
        'grp_no': '1',  # 그룹번호
        'refresh': '1',  # 기존등록유지여부
        "data": [{
            "item": ["", "", "005930", "005930", "005930", "005930", "005930", "005930", "0s"],
            "type": ["00", "04", "0A", "0B", "0C", "0D", "0E", "0g", "0s"]
        }]
    })

    # 수신 작업이 종료될 때까지 대기
    await receive_task


# asyncio로 프로그램을 실행
if __name__ == '__main__':
    asyncio.run(main())
