import time
from copy import deepcopy
from collections import deque

from requests import request
from kiwoom_python.model import *


class RequestThrottler:
    def __init__(self, max_requests_per_second: float):
        """
        API 호출 횟수 제한용 클래스.
        :param max_requests_per_second: 1초 동안 최대로 보낼 수 있는 요청 회수
        """
        if max_requests_per_second <= 0:
            raise ValueError("max_requests_per_second은 0보다 커야합니다.")
        self.max_requests_per_second = max_requests_per_second
        self.last_request_timestamp = time.time()
        self.q = deque()

    def get_wait_time(self) -> float:
        """
        초당 요청 횟수를 유지하기 위해 대기를 얼마나 해야하는지
        슬라이딩 윈도우 알고리즘 기반
        :return: 대기해야할 시간
        """
        # 너무 큰 경우 사실상 제한이 없는 것으로 취급. (키움 api는 1초에 5번)
        if self.max_requests_per_second > 1000000:
            return 0.0

        now = time.time()

        # T-1 이전 기록 제거
        while len(self.q) and now - self.q[0] > 1.0:
            self.q.popleft()

        # 이전 요청들 개수가 최대값 미만인 경우 즉시 허용
        if len(self.q) < self.max_requests_per_second:
            self.q.append(now)
            return 0.0

        # 이전 요청이 5개인 경우. 가장 오래된 시각+1초 까지 대기하도록 대기시간 리턴.
        return 1.0 - (now - self.q[0])


class KiwoomAPI:
    def __init__(self, app_key, app_secret, mock=True):
        """
        API 래퍼 인스턴스를 생성.
        :param app_key: App Key
        :param secret_key: App Secret
        :param mock: 모의투자 여부. 기본값은 True.
        """
        self.host = "https://mockapi.kiwoom.com" if mock else "https://api.kiwoom.com"
        self.mock = mock
        self._app_key = app_key
        self._app_secret = app_secret
        self.token = self._issue_token()

    def _issue_token(self):
        token = Token()
        endpoint = "/oauth2/token"
        headers = {
            "Content-Type": "application/json;charset=UTF-8"
        }
        body = {
            "grant_type": "client_credentials",
            "appkey": self._app_key,
            "secretkey": self._app_secret
        }
        response = request("POST", self.host + endpoint, headers=headers, json=body)
        if response.status_code != 200:
            raise Exception(f"HTTP error. {json.loads(response.content.decode('utf-8'))['return_msg']}")
        token.from_response(response.content.decode("utf-8"))
        return token

    def _refresh_token(self):
        if not self.token.is_valid():
            self._token = self._issue_token()

    def invalidate_token(self):
        '''
        토큰을 폐기.
        :return: 없음
        '''
        endpoint = "/oauth2/token"
        headers = {
            "Content-Type": "application/json;charset=UTF-8"
        }
        body = {
            "grant_type": "client_credentials",
            "appkey": self._app_key,
            "secretkey": self._app_secret
        }
        self.post(endpoint, headers, body)

    def post(self, endpoint: str, headers: dict, body: dict, cont_yn="N", next_key="", request_throttler: RequestThrottler=None):
        """
        POST 요청
        :param endpoint: URL
        :param headers: 헤더 설정. authorization, Content-Type, cont-yn, next-key는 메소드에서 자동 처리
        :param body: 요청 내용
        :param cont_yn: 연속조회여부
        :param next_key: 연속조회키
        :param request_throttler: Request Throttler
        :return: requests.Response 객체
        """
        if request_throttler is None:
            request_throttler = RequestThrottler(5)  # default throttle
        wait_time = request_throttler.get_wait_time()
        if wait_time > 0:
            time.sleep(wait_time)
        self._refresh_token()
        headers["authorization"] = self.token.token_type + ' ' + self.token.token
        headers["Content-Type"] = 'application/json;charset=UTF-8'
        headers["cont-yn"] = cont_yn
        headers["next-key"] = next_key
        ret = request("POST", self.host + endpoint, headers=headers, json=body)
        deserialized = {
            "headers": ret.headers,
            "content": json.loads(ret.content.decode("utf-8")),
            "status_code": ret.status_code,
            "reason": ret.reason
        }
        return deserialized

    def continuous_query(
            self,
            endpoint: str,
            headers: dict,
            body: dict,
            continuous_data_name: str,
            amount: int = 100,
            max_request: int = 300,
            request_throttler: RequestThrottler = None
    ) -> dict:
        """
        연속 데이터를 지정한 범위(0 이하인 경우 끝날 때 까지) 받아옴.
        :param endpoint: api 엔드포인트 주소
        :param headers: 요청 헤더
        :param body: 요청 내용
        :param continuous_data_name: 연속 데이터를 포함하는 리스트의 키 값
        :param amount: 최소 요쳥량. 받아온 데이터 개수가 이 값을 넘으면 요청을 중단하고 리턴. 음수인 경우 제한을 두지 않음.
        :param max_request: 최대 요청 횟수.
        :param request_throttler: Request Throttler
        :return: 받아온 데이터를 병합한 딕셔너리
        """
        assert max_request > 0, "최대 요청 횟수 max_request는 0보다 커야 합니다."
        cont_yn = "N"
        next_key = ""
        continuous_data = []
        cnt = 0
        timestamp = time.time()
        resp_raw = None
        while True:
            if 0 < amount <= len(continuous_data) or cnt > max_request:
                break

            # api 호출 - 디코딩 - 파싱
            response = self.post(endpoint, headers, body, cont_yn, next_key, request_throttler=request_throttler)
            if response["status_code"] >= 400:
                print(f"[api] 오류 코드 {response['status_code']} - {response['reason']}")
                raise
            resp_json = response["content"]

            # 데이터 처리
            resp_raw = deepcopy(resp_json)
            cont_yn = response["headers"]["cont-yn"]
            if resp_json["return_code"] > 0:
                break
            tmp = resp_json[continuous_data_name]
            continuous_data += tmp[:]
            tmp.clear()
            if cont_yn == "N":
                break
            next_key = response["headers"]["next-key"]
        resp_raw[continuous_data_name] = continuous_data
        response["content"] = resp_raw
        return response


if __name__ == "__main__":
    appkey = "CAJbpNofdEzBVpSC23SRRvkD8qxUxqJRjM5dagIp1PU"
    secretkey = "Sty0POpQV4Lk5OyfhKd09OzwCptnh9WQdgIfWlkpmTo"
    api = KiwoomAPI(appkey, secretkey, mock=True)
    # headers = {
    #     'api-id': 'ka10081'
    # }
    # body = {
    #     'stk_cd': '005930',
    #     'base_dt': '20180508',
    #     'upd_stkpc_tp': '0'
    # }
    # response = api.post("/api/dostk/chart", headers, body, "N", "")
    # print(json.loads(response.content.decode("utf-8")))
    # print(response.headers)
