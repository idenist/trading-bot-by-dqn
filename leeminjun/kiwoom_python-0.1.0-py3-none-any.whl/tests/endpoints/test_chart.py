import unittest
from kiwoom_python.api import KiwoomAPI
from kiwoom_python.endpoints.chart import Chart

from tests.test_config import APP_KEY, SECRET_KEY


class TestChart(unittest.TestCase):
    def test_chart_methods_no_error(self):
        """
        Chart 클래스의 메서드들이 오류 없이 실행되는지 테스트
        """
        # Given: KiwoomAPI가 mock 모드로 초기화되고 Chart 클래스가 인스턴스화되었을 때
        try:
            api = KiwoomAPI(APP_KEY, SECRET_KEY, mock=True)
            chart = Chart(api)
        except Exception as e:
            self.fail(f"Initialization failed: {e}")

        # When: 각 메서드가 호출될 때
        try:
            # 주식일봉차트조회
            daily_chart = chart.get_stock_daily_chart(stock_code="005930", base_date="20240101", updated_stock_price_type=True, amount=10)
            self.assertIsNotNone(daily_chart, "get_stock_daily_chart should return a value")

            # 주식분봉차트조회
            minute_chart = chart.get_stock_minute_chart(stock_code="005930", tick_scope=60, updated_stock_price_type=True, amount=10)
            self.assertIsNotNone(minute_chart, "get_stock_minute_chart should return a value")

            # 주식틱차트조회
            tick_chart = chart.get_stock_tick_chart(stock_code="005930", tick_scope=1, updated_stock_price_type=True, amount=10)
            self.assertIsNotNone(tick_chart, "get_stock_tick_chart should return a value")

        except Exception as e:
            # Then: 예외가 발생하지 않아야 함
            self.fail(f"Method call failed with exception: {e}")


if __name__ == '__main__':
    unittest.main()